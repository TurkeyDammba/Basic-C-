#include "Tema.h"

void cargar(tTema &actual){
	//no entiendo la utilidad de esta funcion
}

void mostrar(const tTema &actual){
	cout << actual.titulo << "  " << actual.interprete << "  "
		<< actual.seg << "seg." << endl;
}
